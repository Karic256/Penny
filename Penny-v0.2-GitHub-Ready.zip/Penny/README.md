# Penny — Private Android Financial Tracker

Penny is an offline-first Android app that reads financial SMS alerts only after the phone owner grants permission. It detects likely transactions, stores them locally, calculates monthly income and spending, and exports a CSV backup.

## Version 0.2
- Reads existing financial SMS after permission is granted.
- Tracks new incoming transaction alerts automatically.
- Ignores likely OTP, PIN and verification messages.
- Shows monthly income, spending and net movement.
- Keeps transaction data in a local SQLite database.
- Exports all detected records to CSV.
- Includes a GitHub Actions workflow that builds an installable debug APK without Android Studio.

## Privacy model
- No INTERNET permission.
- No contacts, location, camera, microphone or SEND_SMS permission.
- SMS content and financial records remain on the phone.
- Android backups are disabled.

## Build the APK using GitHub
1. Upload the complete project to a GitHub repository while preserving its folder structure.
2. Open the repository's **Actions** tab.
3. Select **Build Penny APK**.
4. Tap **Run workflow**.
5. When the build finishes, open it and download the **Penny-debug-apk** artifact.
6. Extract the downloaded artifact and install `app-debug.apk` on your Android phone.

Android may ask you to allow installation from your browser or file manager. This build is for private testing and is not a Play Store release.

## Important limitation
Financial SMS formats differ by bank and mobile-money provider. The generic parser will need adjustment using anonymised examples from the exact MTN, Airtel and bank alerts used on your phone.
